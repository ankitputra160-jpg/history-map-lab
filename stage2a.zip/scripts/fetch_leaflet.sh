#!/usr/bin/env bash
# Puts Leaflet into app/src/main/assets/web/lib/leaflet/ so the APK works offline.
# - Exact pinned version, installed from the official npm package.
# - leaflet.js and leaflet.css are verified against the SHA-256 (SRI) hashes
#   published on https://leafletjs.com/download.html for version 1.9.4.
# - The build FAILS if anything does not match. Nothing is silently accepted.
set -euo pipefail

LEAFLET_VERSION="1.9.4"
EXPECT_JS="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo="
EXPECT_CSS="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY="
DEST="app/src/main/assets/web/lib/leaflet"

sri() { printf 'sha256-%s' "$(openssl dgst -sha256 -binary "$1" | openssl base64 -A)"; }

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

( cd "$TMP" \
  && npm init -y >/dev/null 2>&1 \
  && npm install "leaflet@${LEAFLET_VERSION}" --save-exact --ignore-scripts --no-audit --no-fund )

PKG="$TMP/node_modules/leaflet"
INSTALLED="$(node -p "require('$PKG/package.json').version")"
if [ "$INSTALLED" != "$LEAFLET_VERSION" ]; then
  echo "ERROR: expected Leaflet $LEAFLET_VERSION but got $INSTALLED" >&2
  exit 1
fi

GOT_JS="$(sri "$PKG/dist/leaflet.js")"
GOT_CSS="$(sri "$PKG/dist/leaflet.css")"
if [ "$GOT_JS" != "$EXPECT_JS" ]; then
  echo "ERROR: leaflet.js hash mismatch: $GOT_JS (expected $EXPECT_JS)" >&2
  exit 1
fi
if [ "$GOT_CSS" != "$EXPECT_CSS" ]; then
  echo "ERROR: leaflet.css hash mismatch: $GOT_CSS (expected $EXPECT_CSS)" >&2
  exit 1
fi

mkdir -p "$DEST/images"
cp "$PKG/dist/leaflet.js" "$PKG/dist/leaflet.css" "$DEST/"
cp "$PKG"/dist/images/* "$DEST/images/"
cp "$PKG/LICENSE" "$DEST/LICENSE"

for f in leaflet.js leaflet.css LICENSE images/layers.png; do
  [ -s "$DEST/$f" ] || { echo "ERROR: $DEST/$f missing after copy" >&2; exit 1; }
done
echo "OK: Leaflet $INSTALLED (hash verified) is in $DEST"
