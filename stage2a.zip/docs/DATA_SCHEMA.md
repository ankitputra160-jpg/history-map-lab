# रिकॉर्ड की संरचना (Data Schema v1)

हर महत्वपूर्ण रिकॉर्ड में ये फ़ील्ड होंगे:

| फ़ील्ड | अर्थ |
|---|---|
| `id` | अद्वितीय पहचान (जैसे `state_up`) |
| `name_hi`, `name_en` | हिंदी और अंग्रेज़ी नाम |
| `category` | श्रेणी |
| `description` | विवरण |
| `coordinates` | `{lat, lon, source, precision}` या `null` (अनुमान से भरना मना है) |
| `period` | ऐतिहासिक काल, जहाँ लागू हो |
| `source` | `{title, publisher, url, accessed}` |
| `verification_status` | `verified` / `partially_verified` / `pending` |
| `last_verified` | `YYYY-MM-DD` या `null` |
| `license` | डेटा का लाइसेंस |

डिफ़ॉल्ट स्थिति हमेशा `pending` है।
