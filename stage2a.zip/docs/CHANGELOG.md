# Changelog

## 0.1.0-stage2a — Android प्रोजेक्ट की नींव
जोड़ा गया:
- Gradle (Kotlin DSL) प्रोजेक्ट, पिन किए गए संस्करणों के साथ
- `MainActivity` + WebView + `WebViewAssetLoader`
- लोकल HTML/CSS/JS ढाँचा (`index.html`, `app.js`, `map-core.js`, `data-loader.js`)
- Leaflet 1.9.4 का hash-जाँचा हुआ fetch-script
- डेटा फ़ोल्डर संरचना, `manifest.json`, डेटा-स्कीमा दस्तावेज़
- Launcher icon (अस्थायी, सरल डिज़ाइन)

अभी नहीं है / जाँचा नहीं गया:
- कोई भौगोलिक डेटा (नक्शा जानबूझकर खाली)
- GitHub Actions पर APK build अभी तक चलाकर जाँचा नहीं गया
- किसी असली फ़ोन पर परीक्षण नहीं हुआ
