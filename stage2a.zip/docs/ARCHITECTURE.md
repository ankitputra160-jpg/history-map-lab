# Architecture (Stage 1 के आधार पर)

- Kotlin में एक `MainActivity` जो WebView चलाती है।
- वेब सामग्री `app/src/main/assets/web/` में है और `WebViewAssetLoader` के ज़रिए
  `https://appassets.androidplatform.net/assets/web/` से परोसी जाती है (file:// नहीं)।
- Leaflet 1.9.4 build के दौरान `scripts/fetch_leaflet.sh` से आता है (hash-जाँच के साथ)।
- डेटा: GeoJSON/JSON, `assets/web/data/<module>/` में, मॉड्यूल के हिसाब से अलग।
- कोई Android permission नहीं (Stage 2A)। INTERNET तभी जुड़ेगा जब वैकल्पिक online base map आएगा।

## पिन किए गए संस्करण
| घटक | संस्करण |
|---|---|
| Android Gradle Plugin | 8.5.2 |
| Kotlin | 1.9.24 |
| Gradle | 8.9 (CI में स्थापित; wrapper अभी नहीं) |
| JDK | 17 |
| compileSdk / targetSdk / minSdk | 34 / 34 / 21 |
| androidx.webkit | 1.11.0 |
| Leaflet | 1.9.4 |

## Offline / online
- ऑफ़लाइन: ऐप का ढाँचा, नक्शे का canvas, सारा bundled डेटा।
- ऑनलाइन चाहिए: (भविष्य में) OSM-संगत base map tiles। इन्हें offline काम करने वाला नहीं कहा जाएगा।
