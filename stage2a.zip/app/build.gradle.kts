plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.historymaplab.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.historymaplab.app"
        minSdk = 21          // low-end / older Android phones
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0-stage2a"
    }

    buildTypes {
        debug {
            // Debug APK only for now. Signed release steps come in Stage 5.
        }
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // The ONLY third-party runtime dependency: serves bundled web assets
    // over https://appassets.androidplatform.net/ so no file:// access is needed.
    implementation("androidx.webkit:webkit:1.11.0")
}
