This folder holds third-party browser libraries.

lib/leaflet/ is NOT stored in git. It is created during the build by
scripts/fetch_leaflet.sh (Leaflet 1.9.4, from the official npm package,
verified against the SHA-256 hashes published on leafletjs.com).
