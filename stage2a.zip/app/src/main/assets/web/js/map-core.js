/* Creates the Leaflet map. Stage 2A: no base map and no data layers on purpose. */
(function (global) {
  'use strict';
  var HML = (global.HML = global.HML || {});

  HML.mapCore = {
    // Initial camera only (a view position, not geographical data).
    INITIAL_CENTER: [22.5, 80.0],
    INITIAL_ZOOM: 4,

    create: function (elementId) {
      var map = L.map(elementId, {
        zoomControl: true,
        minZoom: 3,
        maxZoom: 12,
        preferCanvas: true,
        worldCopyJump: false
      });
      map.attributionControl.setPrefix('Leaflet');
      L.control.scale({ imperial: false }).addTo(map);
      map.setView(this.INITIAL_CENTER, this.INITIAL_ZOOM);
      return map;
    }
  };
})(window);
