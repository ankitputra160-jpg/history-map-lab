/* Bootstrap: starts the map and shows which datasets are still pending. */
(function () {
  'use strict';
  var HML = window.HML || {};
  var statusEl = document.getElementById('status');
  var listEl = document.getElementById('modules');

  var STATUS_LABELS = {
    pending: 'डेटा प्रतीक्षित',
    partially_verified: 'आंशिक रूप से सत्यापित',
    verified: 'सत्यापित'
  };

  function setStatus(text, kind) {
    statusEl.textContent = text;
    statusEl.className = 'status ' + (kind || '');
  }

  function renderModules(manifest) {
    manifest.modules.forEach(function (m) {
      var li = document.createElement('li');
      var name = document.createElement('span');
      var tag = document.createElement('span');
      name.textContent = m.name_hi + ' (' + m.name_en + ')';
      tag.className = 'tag';
      tag.textContent = STATUS_LABELS[m.status] || m.status;
      li.appendChild(name);
      li.appendChild(tag);
      listEl.appendChild(li);
    });
  }

  if (typeof L === 'undefined') {
    setStatus('Leaflet लोड नहीं हुआ। Build के दौरान scripts/fetch_leaflet.sh सफल होना चाहिए।', 'error');
  } else {
    try {
      HML.mapCore.create('map');
      setStatus('नक्शे का ढाँचा चालू है (अभी कोई सीमा-डेटा नहीं)।', 'ok');
    } catch (e) {
      setStatus('नक्शा शुरू नहीं हो सका: ' + e.message, 'error');
    }
  }

  HML.data.loadJSON('data/manifest.json')
    .then(renderModules)
    .catch(function (e) {
      var li = document.createElement('li');
      li.textContent = 'डेटा-सूची लोड नहीं हुई: ' + e.message;
      listEl.appendChild(li);
    });
})();
