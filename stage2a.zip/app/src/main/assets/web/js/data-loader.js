/* Loads JSON datasets bundled in assets/web/data/. No network access involved. */
(function (global) {
  'use strict';
  var HML = (global.HML = global.HML || {});

  HML.data = {
    loadJSON: function (path) {
      return fetch(path).then(function (response) {
        if (!response.ok) {
          throw new Error(path + ' → HTTP ' + response.status);
        }
        return response.json();
      });
    }
  };
})(window);
