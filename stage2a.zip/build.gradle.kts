// Root build file. Plugin versions are pinned here (see docs/ARCHITECTURE.md).
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
